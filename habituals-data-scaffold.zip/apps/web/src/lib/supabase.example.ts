import { createSupabaseClient } from "@habituals/data"

export const dataClient = createSupabaseClient({
  url: import.meta.env.VITE_SUPABASE_URL!,
  anonKey: import.meta.env.VITE_SUPABASE_ANON_KEY!,
})

// Optional: add headers like x-request-id / timezone
dataClient.setRequestDecorator?.((h) => ({
  ...h,
  "x-request-id": (typeof crypto !== "undefined" && 'randomUUID' in crypto) ? crypto.randomUUID() : String(Date.now()),
  "x-timezone": Intl.DateTimeFormat().resolvedOptions().timeZone,
}))
