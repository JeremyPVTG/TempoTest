import { makeHabitsRepo, createHabitsQueries, createHabitMutations } from "@habituals/data"
import { dataClient } from "./supabase.example"

const repo = makeHabitsRepo({ request: dataClient.request })

export const Q = createHabitsQueries(repo)
export const M = createHabitMutations(repo)
