import { describe, it, expect, vi } from "vitest"
import { z } from "zod"
import { makeHabitsRepo } from "../../repositories/habitsRepo"

// Local schema to keep the example self-contained.
const HabitZ = z.object({ id: z.string(), title: z.string() })

describe("habitsRepo", () => {
  const client = {
    request: vi.fn().mockImplementation(async (_op, parse: any) => {
      const data = [{ id: "h1", title: "Read" }]
      const parsed = parse.safeParse ? parse.safeParse(data) : { success: true, data }
      if (!parsed.success) throw new Error("zod fail")
      return parsed.data
    }),
  }

  it("listHabits parses array", async () => {
    const repo = makeHabitsRepo({ request: client.request as any })
    const items = await repo.listHabits()
    expect(Array.isArray(items)).toBe(true)
    expect(items[0].id).toBe("h1")
  })
})
