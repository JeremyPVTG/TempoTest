import { describe, it, expect } from "vitest"
import React from "react"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { renderHook, waitFor } from "@testing-library/react"
import { createHabitsQueries } from "../../hooks/useHabits"

describe("hooks/useHabits", () => {
  it("useHabits returns data from repo", async () => {
    const repo = {
      listHabits: async () => [{ id: "h1", title: "Read" }],
      getStreak: async (_: string) => ({ current: 3, longest: 7 }),
    } as any

    const qc = new QueryClient()
    const wrapper = ({ children }: any) => (
      <QueryClientProvider client={qc}>{children}</QueryClientProvider>
    )
    const Q = createHabitsQueries(repo)

    const { result } = renderHook(() => Q.useHabits(), { wrapper })
    await waitFor(() => expect(result.current.isSuccess).toBe(true))
    expect(result.current.data?.[0]?.id).toBe("h1")
  })
})
