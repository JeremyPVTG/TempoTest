export type DataErrorCode =
  | "E.NETWORK_OFFLINE"
  | "E.TIMEOUT"
  | "E.RLS_FORBIDDEN"
  | "E.VALIDATION_FAILED"
  | "E.CONFLICT_VERSION"
  | "E.UNKNOWN"

export class DataError extends Error {
  code: DataErrorCode
  meta?: Record<string, unknown>

  constructor(code: DataErrorCode, message: string, meta?: Record<string, unknown>) {
    super(message)
    this.code = code
    this.meta = meta
  }
}
