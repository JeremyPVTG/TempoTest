import { z, type ZodTypeAny } from "zod"
// NOTE: Replace this import path with your actual api-contracts location.
import {
  HabitZ,
  NewHabitInputZ,
  UpdateHabitInputZ,
  HabitEventZ,
  MarkDoneInputZ,
  StreakSummaryZ,
  AchievementZ,
} from "@habituals/api-contracts/habits"

type Client = { request: <T>(op: any, parse: ZodTypeAny) => Promise<T> }

export function makeHabitsRepo(client: Client) {
  return {
    listHabits: () => client.request((c: any) => c.from("habits").select("*"), z.array(HabitZ)),

    createHabit: (input: z.infer<typeof NewHabitInputZ>) =>
      client.request((c: any) => c.from("habits").insert(input).select().single(), HabitZ),

    updateHabit: (id: string, patch: z.infer<typeof UpdateHabitInputZ>) =>
      client.request((c: any) => c.from("habits").update(patch).eq("id", id).select().single(), HabitZ),

    deleteHabit: (id: string) =>
      client.request((c: any) => c.from("habits").delete().eq("id", id).select().single(), HabitZ),

    markDone: (input: z.infer<typeof MarkDoneInputZ>) =>
      client.request((c: any) => c.rpc("mark_habit_done", input), HabitEventZ),

    undoEvent: (eventId: string) =>
      client.request((c: any) => c.rpc("undo_habit_event", { event_id: eventId }), HabitEventZ),

    getStreak: (habitId: string) =>
      client.request((c: any) => c.rpc("get_streak_summary", { habit_id: habitId }), StreakSummaryZ),

    getAchievementsFeed: (cursor?: string | null) =>
      client.request((c: any) => c.rpc("get_achievements_feed", { cursor }), z.array(AchievementZ)),
  }
}
