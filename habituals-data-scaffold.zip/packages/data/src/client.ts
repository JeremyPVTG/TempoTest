import { createClient, type SupabaseClient } from "@supabase/supabase-js"
import type { ZodSchema } from "zod"
import { DataError } from "./types/errors"

export type SupabaseOpts = {
  url: string
  anonKey: string
  fetch?: typeof fetch
  headers?: Record<string, string>
}

type Requester = <T>(
  op: (c: SupabaseClient) => Promise<{ data: unknown; error: any }>,
  parse: ZodSchema<T>
) => Promise<T>

export function createSupabaseClient(opts: SupabaseOpts) {
  const supabase = createClient(opts.url, opts.anonKey, {
    global: { fetch: opts.fetch, headers: opts.headers },
  })

  let decorateHeaders: (h: Record[string, string]) => Record<string, string> = (h) => h
  // decorateHeaders is reserved for future header injection (x-request-id, x-timezone).

  function setRequestDecorator(cb: typeof decorateHeaders) {
    decorateHeaders = cb
  }

  const request: Requester = async (op, parse) => {
    try {
      const { data, error } = await op(supabase)
      if (error) throw toDataError(error)
      const parsed = parse.safeParse(data)
      if (!parsed.success) {
        throw new DataError("E.VALIDATION_FAILED", parsed.error.message, { zod: parsed.error.issues })
      }
      return parsed.data
    } catch (err: any) {
      if (err instanceof DataError) throw err
      throw toDataError(err)
    }
  }

  function toDataError(e: any): DataError {
    const msg = String(e?.message ?? e)
    const code = normalizeCode(e)
    return new DataError(code, msg, { raw: e })
  }

  function normalizeCode(e: any) {
    const status = e?.status ?? e?.code
    if (status === 401 || status === 403) return "E.RLS_FORBIDDEN"
    if (status === 408) return "E.TIMEOUT"
    if (status === "ETIMEDOUT") return "E.TIMEOUT"
    if (status === "ENOTFOUND" || String(e).includes("Failed to fetch")) return "E.NETWORK_OFFLINE"
    return "E.UNKNOWN"
  }

  return { supabase, request, setRequestDecorator }
}
