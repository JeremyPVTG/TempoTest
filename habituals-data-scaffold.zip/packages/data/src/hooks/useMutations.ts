import { useMutation, useQueryClient } from "@tanstack/react-query"
import { makeHabitsRepo } from "../repositories/habitsRepo"
import { makeIdempotencyKey } from "@habituals/domain/idempotency"

export function createHabitMutations(repo: ReturnType<typeof makeHabitsRepo>) {
  const qc = useQueryClient()

  return {
    useCreateHabit: () =>
      useMutation({
        mutationFn: (input: any) => repo.createHabit(input),
        onSuccess: () => qc.invalidateQueries({ queryKey: ["habits"] }),
      }),

    useUpdateHabit: () =>
      useMutation({
        mutationFn: ({ id, patch }: { id: string; patch: any }) => repo.updateHabit(id, patch),
        onSuccess: (_d, { id }) => {
          qc.invalidateQueries({ queryKey: ["habits"] })
          qc.invalidateQueries({ queryKey: ["streak", id] })
        },
      }),

    useDeleteHabit: () =>
      useMutation({
        mutationFn: (id: string) => repo.deleteHabit(id),
        onSuccess: () => qc.invalidateQueries({ queryKey: ["habits"] }),
      }),

    useMarkDone: () =>
      useMutation({
        mutationFn: (payload: any) => repo.markDone({ ...payload, idempotency_key: makeIdempotencyKey() }),
        onSuccess: (_event, { habit_id }: any) => {
          qc.invalidateQueries({ queryKey: ["habits"] })
          qc.invalidateQueries({ queryKey: ["streak", habit_id] })
        },
      }),

    useUndoEvent: () =>
      useMutation({
        mutationFn: (eventId: string) => repo.undoEvent(eventId),
        onSuccess: () => qc.invalidateQueries({ queryKey: ["habits"] }),
      }),
  }
}
