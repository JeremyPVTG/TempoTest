import { useQuery } from "@tanstack/react-query"
import { makeHabitsRepo } from "../repositories/habitsRepo"

export function createHabitsQueries(repo: ReturnType<typeof makeHabitsRepo>) {
  return {
    useHabits: () =>
      useQuery({
        queryKey: ["habits"],
        queryFn: () => repo.listHabits(),
        staleTime: 15_000,
      }),
    useStreak: (habitId: string) =>
      useQuery({
        queryKey: ["streak", habitId],
        queryFn: () => repo.getStreak(habitId),
        enabled: !!habitId,
      }),
  }
}
