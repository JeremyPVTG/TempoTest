# @habituals/data — Scaffolding

This package provides a dependency-injected Supabase client, typed repositories, and initial React Query hooks.

## Install (workspace)
- Ensure `@supabase/supabase-js`, `zod`, and `@tanstack/react-query` are installed.
- In your app, create a client and wire hooks as shown in `apps/web/src/lib/*.example.ts`.

## Public API
- `createSupabaseClient(opts)` → `{ supabase, request, setRequestDecorator }`
- `makeHabitsRepo(client)` → typed repo methods (list, create, update, delete, markDone, undoEvent, getStreak, getAchievementsFeed)
- `createHabitsQueries(repo)` → `useHabits`, `useStreak`
- `createHabitMutations(repo)` → mutation hooks

## Notes
- Replace `@habituals/api-contracts/habits` import with your actual zod schema path.
- RPC/table names are placeholders—adapt to your DB objects.
- Add offline queue + optimistic updates in the next step.
